<!-- Download View -->

<div class="two-thirds column">
    <h3>Download</h3>
    <p>
        <a href="/static/files/easyapp.v0.1.zip" class="button" title="easyapp.v0.1.zip">EasyApp v0.1 Zip</a> 
        <a href="https://github.com/atulmy/easyapp" target="_blank" class="button" title="Github repository">EasyApp on Github by @atulmy</a>
    </p>
</div>