<!-- Footer -->
    <div class="sixteen columns">
        <hr />
        <h6 style="color: #666666;">Copyright Notice &copy; <?php echo date('Y'); ?>. All rights reserved.</h6>
        <br/>
    </div>