<?php
/* 
 * includes/config.php
 * User defined constants
 */

// define('EXAMPLE', 'EXAMPLE');
?>